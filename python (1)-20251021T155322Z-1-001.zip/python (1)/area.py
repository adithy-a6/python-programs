cal_sq_area=lambda side_length:side_length**2
cal_re_area=lambda length,width:length**width
cal_tr_area=lambda base,height:0.5*base*height


sqs=int(input("enter the side of the square:"))
sq_area=cal_sq_area(sqs)
print("Area of the square:",sq_area)


print("enter the base and height of he triangle:")
ht=int(input("Height: "))
bs=int(input("Base:"))
tri_area=cal_tr_area(bs,ht)
print("Area of the triangle:",tri_area)


print("enter the lenght nd breadth of rectangle:")
l=int(input("Length:"))
b=int(input("Breadth:"))
rec_area=cal_re_area(l,b)
print("Area of the triangle:",rec_area)
