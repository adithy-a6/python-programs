import math
import random
import datetime
random_number=random.randint(1,100)
print(f"Random number between 1 and 100:{random_number}")
current_datetime=datetime.datetime.now()
print(f"Current date and time:{current_datetime}")
number=int(input("Enter a number:"))
square_root=math.sqrt(number)
print(f"The square root of{number} is:{square_root}")
