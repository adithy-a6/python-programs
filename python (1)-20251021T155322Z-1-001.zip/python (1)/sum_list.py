num_list=[]
n=int(input("enter the number of values in list:"))
print("ENTER THE ELEMENTS TO THE LIST:")
for i in range(n):
    val=int(input())
    num_list.append(val)
total=0
for item  in num_list:
    total=total+item
print("The sum of all items in the list is:",total)
