file=input("Enter the filename:")
file_list=file.split(".")
print("File extension is:",file_list[-1])
