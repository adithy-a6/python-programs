n=int(input("Enter the value of 'n':"))
print("n+nn+nnn=",n+(n*n)+(n*n*n))
