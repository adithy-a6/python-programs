import math
r=float(input("Enter the radius of the circle:"))
area=math.pi*r*r
print("Area of the circle:",area,"square unit")
