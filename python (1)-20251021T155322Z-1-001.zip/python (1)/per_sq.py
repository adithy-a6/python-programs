res=[]
start=int(input("Enter the starting range(4 digit number):"))
end=int(input("Enter the ending range(4 digit number):"))
if start<1000 or end>9999 or start> end:
    print("Invalid range.Please Enter a valid 4 digit range:")
else:
    for num in range(start,end+1):
      if num%2==0:
          root=int(num**0.5)
          if root*root==num:
              res.append(num)
print("Four-digit even perfect square number in the given range:")
print(res)
          
    
